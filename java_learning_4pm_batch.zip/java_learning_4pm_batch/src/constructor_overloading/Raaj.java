package constructor_overloading;

class Whatsapp
{
    Whatsapp(int a)
	{
		System.out.println("send one image at a time");
	}
	Whatsapp(int a, int b)
	{
		System.out.println("Send two images at a time");
	}
	Whatsapp(int a, int b, int c)
	{
		System.out.println("Send 3 images at a time ");
	}
}

public class Raaj {

	public static void main(String[] args) 
	{
		new Whatsapp(1,1,2);
	}
}
