package encapsultation_programs;
class Gmail{
	private String username = "raaj";  // no access what so ever
	private String password = "11111";   // old password
	
	public String getUsername()	{
		return username;
	}
	
	public void setUsername(String username)	{
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}

public class Raaj {

	public static void main(String[] args)
	{
       Gmail g = new Gmail();
       System.out.println("My old username was");
       System.out.println(g.getUsername());    
       g.setUsername("raaj1234");        // setting a new username
       System.out.println("My new username is ");
       System.out.println(g.getUsername());
       
       System.out.println("My old password was");
       System.out.println(g.getPassword());
       
       g.setPassword("abcd1234");   // setting a new password
       
       System.out.println("My new password is ");
       System.out.println(g.getPassword());
	}
}
