package c_programs;

import java.util.Iterator;
import java.util.Vector;

public class VectorRunning {

	public static void main(String[] args) 
	{
		Vector l1 = new Vector();
		l1.add(10);
		l1.add(23.45);
		l1.add('a');
		l1.add(null);
		l1.add("ecoders");
		l1.add(10);
		
		System.out.println(l1);                 // prints all the elements of the collection l1
		System.out.println(l1.contains(10));    // checks if the collection has those items or not
		System.out.println(l1.indexOf(10));     // gives the first index of 10
		System.out.println(l1.lastIndexOf(10)); // gives the last index of 10
		// to fetch the items using the index values we use get() function and we pass the index value
		System.out.println(l1.get(0));          //10
		System.out.println(l1.get(2));          //a
		System.out.println(l1.size()); // prints total number of elements in the collection.
		
		System.out.println("\nPrinting the collection using the Iterator interface, and applying iterator() function on our collection.");
		Iterator itr=l1.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());
		}

	}

}
