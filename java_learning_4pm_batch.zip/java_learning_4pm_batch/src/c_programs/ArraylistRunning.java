package c_programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ArraylistRunning {

	public static void main(String[] args) 
	{
		ArrayList l1 = new ArrayList();
		l1.add(10);
		l1.add(23.45);
		l1.add('a');
		l1.add(null);
		l1.add("ecoders");
		l1.add(10);
		
		System.out.println(l1);                 // prints all the elements of the collection l1
		System.out.println(l1.contains(10));    // checks if the collection has those items or not
		System.out.println(l1.indexOf(10));     // gives the first index of 10
		System.out.println(l1.lastIndexOf(10)); // gives the last index of 10
		// to fetch the items using the index values we use get() function and we pass the index value
		System.out.println(l1.get(0));          //10
		System.out.println(l1.get(2));          //a
		System.out.println(l1.size()); // prints total number of elements in the collection.
		
		// making generic collection by using the <> brackets
		ArrayList<Integer> l2 = new ArrayList<Integer>();
		l2.add(60);
		l2.add(50);
		l2.add(20);
		l2.add(30);
		l2.add(40);
		l2.add(50);
		System.out.println(l2);
		//System.out.println(l2.addAll(l1));
		System.out.println(l2.containsAll(l1));    //check if all the elements of l1 are present in l2
		System.out.println(l2);
		Collections.sort(l2);  // Collections is a class which is used to sort the Collection interface items
		System.out.println(l2);
		
		System.out.println("\nPrinting the collection using the Iterator interface, and applying iterator() function on our collection.");
		Iterator itr=l1.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}
	}
}
