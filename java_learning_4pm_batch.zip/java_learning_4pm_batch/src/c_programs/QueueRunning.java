package c_programs;

import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueRunning {

	public static void main(String[] args) 
	{
		PriorityQueue l1 = new PriorityQueue();
		l1.add(10);
		l1.add(23);
		l1.add(55);
		//l1.add(null);  // null values are not allowed
		l1.add(5);
		l1.add(2);
		l1.add(2);        // duplicates are allowed
		
		System.out.println(l1);                 // prints all the elements of the collection l1
		System.out.println(l1.contains(10));    // checks if the collection has those items or not
	//	System.out.println(l1.indexOf(10));     // cannnot fetch the values using index
	//	System.out.println(l1.lastIndexOf(10)); // cannot fetch the values using index

		System.out.println(l1.size()); // prints total number of elements in the collection.
		
		
		System.out.println("\nPrinting the collection using the Iterator interface, and applying iterator() function on our collection.");
		Iterator itr=l1.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());
		}

	}

}
