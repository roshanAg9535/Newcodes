package set_collection_programs;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHAshSetRunning 
{
 public static void main(String[] args) 
   {
	 LinkedHashSet l1 = new LinkedHashSet();
		l1.add(40);
		l1.add(20);
		l1.add(20);
		l1.add(null);
		l1.add(30);
		l1.add(40);
		l1.add(20);
		l1.add(20);
		l1.add(null);
		l1.add(30);

		
		System.out.println(l1);
		
		System.out.println(l1.contains(10));    // checks if the collection has those items or not
	//	System.out.println(l1.indexOf(10));     // cannnot fetch the values using index
	//	System.out.println(l1.lastIndexOf(10)); // cannot fetch the values using index

		System.out.println(l1.size()); // prints total number of elements in the collection.
		
		
		System.out.println("\nPrinting the collection using the Iterator interface, and applying iterator() function on our collection.");
		Iterator itr=l1.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());
   }
}
 
}
