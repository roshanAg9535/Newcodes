package set_collection_programs;

import java.util.*;

public class TreeSetRunning {
	public static void main(String[] args) 
	{
		//  The objects of the TreeSet class are stored in ascending order.
        //	TreeSet class doesn't allow null element.
        //	doesnt allow duplicates

		  TreeSet al=new TreeSet();  
		  al.add("Ravi");  
		  al.add("Vijay");  
		  al.add("Ravi");  
		  al.add("Ajay");  
		  //Traversing elements  
		  Iterator<String> itr=al.iterator();  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
	}
}
