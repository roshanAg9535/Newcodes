package set_collection_programs;

import java.util.HashSet;
import java.util.Iterator;

//dont maintain order of insertion
// will not allow null values
// set will not allow duplicate values

public class HashsetRunning {

	public static void main(String[] args) 
	{
		HashSet l1 = new HashSet();
		
		l1.add(20);
		l1.add(20);
		l1.add(null);
		l1.add(30);
		l1.add(40);
		l1.add(20);
		l1.add(20);
		l1.add(null);
		l1.add(30);
		l1.add(40);
		
		System.out.println(l1);
		
		System.out.println(l1.contains(10));    // checks if the collection has those items or not
	//	System.out.println(l1.indexOf(10));     // cannnot fetch the values using index
	//	System.out.println(l1.lastIndexOf(10)); // cannot fetch the values using index

		System.out.println(l1.size()); // prints total number of elements in the collection.
		
		
		System.out.println("\nPrinting the collection using the Iterator interface, and applying iterator() function on our collection.");
		Iterator itr=l1.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());
		}
	}

}
