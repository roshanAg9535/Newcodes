package run_time_polymorphism;
// single level inheritance 
// non static methods

class Manufacturer
{
	void selllaptop()	{
		System.out.println("WE sell laptops");
	}
}

class Dell extends Manufacturer
{
	void selllaptop()	{
		System.out.println("WE sell dell laptops");
	}
}

class Asus extends Manufacturer
{
	void selllaptop()	{
		System.out.println("WE sell asus laptops");
	}
}

class Apple extends Manufacturer
{	void selllaptop()	{
		System.out.println("WE sell Apple laptops");
	}
}

class Flipkart
{
	void selleverything(Manufacturer m)   // taking many forms 
	{
		m.selllaptop();
	}
}

class Amazon
{
	void selleverything(Manufacturer m)   // taking many forms 
	{
		m.selllaptop();
	}
}

public class RAaj {
	public static void main(String[] args) {
		Dell d = new Dell();
		Asus as = new Asus();
		Apple a = new Apple();
		
		Flipkart f = new Flipkart();
		f.selleverything(as);
		
		Amazon az = new Amazon();
		az.selleverything(d);
		
	}
}
