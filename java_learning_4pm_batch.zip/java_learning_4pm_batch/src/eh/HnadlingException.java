package eh;

public class HnadlingException {

	public static void main(String[] args) 
	{
	   System.out.println("hello ecoders");
	   
	    int a = 7;
	    int b = 2;
	   try
	   {
	   System.out.println(a/b);
	   }
	   catch(ArithmeticException ex)
	   {
		   System.out.println("some error accored, but now its cought");
		   ex.printStackTrace();
	   }
	   
	   
	   System.out.println("\nThank you all . for the wonderful session.see you again..");

	}

}
