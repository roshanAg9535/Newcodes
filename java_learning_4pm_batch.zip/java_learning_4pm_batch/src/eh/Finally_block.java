package eh;

public class Finally_block {

	public static void main(String[] args) 
	{
		 System.out.println("hello ecoders");
		   
		    int a = 7;
		    int b = 0;
		   try
		   {
		   System.out.println(a/b);
		   }

		   
		   
		   finally
		   {
		   System.out.println("\nThank you all . for the wonderful session.see you again..");
		   }

	}

}
