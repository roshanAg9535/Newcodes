package method_overriding;

class Manufacturer
{
	void selllaptop()	{
		System.out.println("we sell all laptops");	
		}
}

class Dell extends Manufacturer
{
	void selllaptop()	{
		System.out.println("we sell dell laptops");	
		}
}

class Lenovo extends Manufacturer
{
	void selllaptop()	{
		System.out.println("we sell lenovo laptops");	
		}
}

class Apple extends Manufacturer
{
	void selllaptop()	{
		System.out.println("we sell Apple laptops");	
		}
}

class Flipkart
{
	void selleverything(Manufacturer m)   // pass by reference 
	{
		m.selllaptop();
	}
}

public class Raaj {
	public static void main(String[] args) {
       Dell d = new Dell();
       Lenovo l = new Lenovo();
       Apple a = new Apple();
       
//       d.selllaptop();
//       l.selllaptop();
//       a.selllaptop();
       
         Flipkart f = new Flipkart();
         f.selleverything(l);
	}

}
