package method_overriding;

class Kaspersky1
{
	void removevirus()
	{
		System.out.println("It removes 1 virus at a time");
	}
}

class Kaspersky2 extends Kaspersky1
{
	void removevirus()
	{
		System.out.println("It removes 1000 virus at a time");
	}
}

public class Gurupeeth {

	public static void main(String[] args) 
	{
		Kaspersky2  k2 = new Kaspersky2();
		k2.removevirus();

	}
}
