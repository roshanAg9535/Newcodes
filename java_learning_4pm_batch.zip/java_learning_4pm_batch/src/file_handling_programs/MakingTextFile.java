package file_handling_programs;

import java.io.File;

public class MakingTextFile {

	public static void main(String[] args)
	{
		// createNewFile()  is function , exists()
		try
		{
			File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\file_handling_programs\\java_4pm_batch_notes\\javanotes.txt");
			
			if(f.exists())
			{
				System.out.println("No need to create, it already exists");
			}
			else
			{
				f.createNewFile();
				System.out.println("File created successfully");
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

}
