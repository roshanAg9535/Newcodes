package file_handling_programs;

import java.io.File;

public class MakingFolder {

	public static void main(String[] args) 
	{
		// mkdir() - make directory 
		
		try
		{
		File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\file_handling_programs\\java_4pm_batch_notes");
		if(f.exists())
		{
			System.out.println("Folder already present");
		}
		else
		{
			f.mkdir();
			System.out.println("Folder successfully created");
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}

}
