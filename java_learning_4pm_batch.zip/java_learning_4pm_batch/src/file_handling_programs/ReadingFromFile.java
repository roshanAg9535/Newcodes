package file_handling_programs;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class ReadingFromFile {

	public static void main(String[] args) 
	{
		try
		{
			File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\file_handling_programs\\java_4pm_batch_notes\\javanotes.txt");
	
			f.delete();
			if(f.exists())
			{
				System.out.println("file not deleted");
			}
			else
			{
				System.out.println("File has been deleted");
			}
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}

}
