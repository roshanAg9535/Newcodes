package file_handling_programs;

import java.io.File;
import java.io.FileWriter;

public class WritingintoFile {

	public static void main(String[] args) 
	{
		try
		{
			File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\file_handling_programs\\java_4pm_batch_notes\\javanotes.txt");
			
			FileWriter fw = new FileWriter(f, true); // append mode
			
			fw.write("\ntoday its 7th class");
			
			fw.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}

}
