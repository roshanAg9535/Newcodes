package calling_functions;

abstract class Sample  
{
	public static void add()    // concrete funtion 
	{
		int a = 10;
		 int b = 20;
		 System.out.println(a+b);
	}
	
	public abstract void subract();   // abract method / function
}

class Test extends Sample
{
	public void subract()
	{
		int m = 20;
		int n = 10;
		System.out.println(m-n);
	}
}

public class Demo {

	public static void main(String[] args)
	{
		Test t = new Test();
		t.add();
		t.subract();

	}

}
