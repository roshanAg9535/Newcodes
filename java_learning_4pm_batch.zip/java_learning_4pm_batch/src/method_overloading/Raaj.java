package method_overloading;

class Facebook
{
	void send(int a)
	{
		System.out.println("Send one message at time");
	}
	void send(int a, int b)
	{
		System.out.println("Send two message at time");
	}
	void send(int a, int b , int c)
	{
		System.out.println("Send three message at time");
	}
}

public class Raaj {

	public static void main(String[] args) 
	{
		Facebook f = new Facebook();
		//f.send(1);
		//f.send(1,2);
		f.send(1,2,3);

	}

}
