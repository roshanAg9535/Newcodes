package introduction_programs;

public class SwitchCase {

	public static void main(String[] args) 
	{
		int a = 2;
		
		switch(a)
		{
		case 1:
		{
			System.out.println("a value entered is 1");
		    break;
		}
		case 2:
		{
			System.out.println("a value enterd is 2");
			break;
		}
		case 3 :
		{
			System.out.println("a value entered is 3");
			break;
		}
		default:
		{
			System.out.println("you have entered the wrong value for a , 1,2,3");
		}
		}
	}
}
