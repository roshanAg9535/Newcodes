package introduction_programs;

// variable :- its a named memory location , in which we can store any kind of data and we can change the data at any time,
// during the execution of the program.

public class Varaibles {

	public static void main(String[] args) 
	{
////		// delcaration of a varaible
////		  int a; 
////		  
////		  // initialize the variable
////		  a = 10;
//		
//		int a = 10;  
//		System.out.println(a);
		
		int sum = 0;
		int a = 10;
		int b = 20;
		sum = a+b;
		
		System.out.println(sum);
		System.out.println("The sum of "+a+" and "+b+" is " + sum);
	}
}
