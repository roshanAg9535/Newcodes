package introduction_programs;
/* loop statements
    while loop
    do while loop
    for 
 */
public class LoopPrograms {

	public static void main(String[] args) 
	{
//		int a = 20;
//		
//		while(a <= 10)
//		{
//			System.out.println(a);
//			a++;   // a = a+1
//		}
		
//		int i = 20;   
//		do
//		{
//			System.out.println(i);
//			i++;
//		}
//		while(i<=10);
		
//		for(int i = 1; i <= 10 ; i++)
//		{
//			System.out.print(i + " ");
//		}
		
	}
}
