package introduction_programs;

// literals :- types of variables :
// 1. number literals  :- int, long,  float, double
// 2. char literals   :- 'a'
// 3. string literals :- "hello ecoders welcome to java programming."
// 4. boolean literals :- true / false

public class Literals {

	public static void main(String[] args) 
	{
		System.out.println(10);
		System.out.println(23.45);
		System.out.println('a');
		System.out.println("hello ecoders welcome to java programming.");
		
		System.out.println("hello i have 10 sudents now in my class");
		
	}

}
