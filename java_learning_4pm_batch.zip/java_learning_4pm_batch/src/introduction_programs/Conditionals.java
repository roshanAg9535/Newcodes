package introduction_programs;

/*
 conditional statements :- 
 if 
 if-else
 switch case
 break
 continue
 */

public class Conditionals {  //jvm
	public static void main(String[] args)
	{
		String name = "ecoders";
		if(name == "ecoders")
		{
			System.out.println("you are welcome to the class");
		}
		else
		{
			System.out.println("access denied");
		}
	}
}
