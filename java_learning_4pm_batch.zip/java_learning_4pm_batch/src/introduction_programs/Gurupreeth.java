package introduction_programs;

public class Gurupreeth 
{

	public static void main(String[] args)    
	// jvm java virtual machine :- running java program and it starts execution from the main function
	{
		 System.out.println("Gurupreeth Singh");
	}

}
