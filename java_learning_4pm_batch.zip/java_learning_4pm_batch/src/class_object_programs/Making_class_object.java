package class_object_programs;

public class Making_class_object {
	
	int a = 10;   // non static 
	static int b = 20;  // static variable

	public static void main(String[] args) 
	{
		// how to create the object of a class
		
		Making_class_object  m = new Making_class_object(); 
		
		   // james Goslin - 
		
		System.out.println(m.a);
		
		System.out.println(b);

	}

}
