package scanner_class;

import java.util.Scanner;

public class Sample {

	public static void main(String[] args) 
	{
		//8 data types :-  byte , short, int , float, long, double, char, String, object
		
		System.out.println("Please enter an integer value");
		Scanner scint = new Scanner(System.in);
		int a = scint.nextInt();
		System.out.println("the integer value given is " + a);
		
		System.out.println("Please enter an decimal value");
		Scanner scfloat = new Scanner(System.in);
		float f = scfloat.nextFloat();
		System.out.println("the decimal value given is " + f);
		
		System.out.println("Please enter an decimal value");
		Scanner scdouble = new Scanner(System.in);
		double d = scdouble.nextDouble();
		System.out.println("the decimal value given is " + d);
		
		System.out.println("Please enter an character value");
		Scanner scchar = new Scanner(System.in);
		char ch = scchar.next().charAt(0);
		System.out.println("the entered character is " + ch);
		
		System.out.println("Please enter the whole word");
		Scanner scword = new Scanner(System.in);
		String s1 = scword.next();
		System.out.println("the word entered is " + s1);
		
		System.out.println("Please enter the whole sentence");
		Scanner sc = new Scanner(System.in);
		String s2 = sc.nextLine();
		System.out.println("the sentence entered is \n" + s2);
		

	}

}
