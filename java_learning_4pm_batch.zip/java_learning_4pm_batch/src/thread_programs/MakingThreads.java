package thread_programs;

class Nameprinting extends Thread
{
	public void run()
	{
		for(int i = 1; i<=100; i++)
		{
			System.out.println("ecoders");
		}
	}
}

class NumberPrinting implements Runnable
{
	public void run()
	{
		for(int i = 1; i<=100; i++)
		{
			System.out.println(i);
		}
	}
}

public class MakingThreads {
	public static void main(String[] args) {
		Nameprinting n1 = new Nameprinting();
		NumberPrinting n2 = new NumberPrinting();
		
		Thread t1 = new Thread(n1);
		Thread t2 = new Thread(n2);
		
		t1.start();
		t2.start();
	}
}
