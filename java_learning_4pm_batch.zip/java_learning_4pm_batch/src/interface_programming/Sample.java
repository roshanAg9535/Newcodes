package interface_programming;

interface Calculator  // only abstract method
{
	void add();
	void subract();
}

// 100% there will be a child class for all the interfaces which give the implementation for all abstract methods of the interface

class Demo implements Calculator
{

	public void add() {
		int  a = 10; int b = 20;
		System.out.println(a+b);
	}

	public void subract() {
		int m = 30;
		int n = 10;
		System.out.println(m-n);
	}
}

public class Sample {

	public static void main(String[] args) {   // jvm
	//	Calculator c = new Calculator();  // we cannot create an object of the interface 
		Calculator c = new Demo();
		c.add();
		c.subract();
	}
}
