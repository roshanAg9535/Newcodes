package fh;

import java.io.File;
import java.util.Scanner;

public class Reading_froma_file {

	public static void main(String[] args)
	{
		try
		{
		File f1 = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\fh\\java_4_5batch_notes\\javanotes.txt");   
            Scanner dataReader = new Scanner(f1);  
            while (dataReader.hasNextLine()) 
                {  
                 String fileData = dataReader.nextLine();  
                 System.out.println(fileData);  
                }  
           dataReader.close();  
           } 
	    catch (Exception exception) {  
            System.out.println("Unexcpected error occurred!");  
            exception.printStackTrace();  
        }  

	}

}
