package fh;

import java.io.File;

public class Creating_folder {

	public static void main(String[] args) 
	{
		try
		{
		File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\fh\\java_4_5batch_notes");
		
		if(f.exists())
		{
			System.out.println("folder already exists.");
		}
		else
		{
			f.mkdir();
			System.out.println("folder created");
		}
		}
		catch(Exception ex)
		{
			System.out.println("An error occured while creating a folder please try again");
			ex.printStackTrace();
		}

	}

}
