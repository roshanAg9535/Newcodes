package fh;

import java.io.File;

public class Making_text_file {

	public static void main(String[] args)
	{
		//createNewFile() is the method used for making a text file
        try
        {
        	File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\fh\\java_4_5batch_notes\\javanotes.txt");
        	
        	if(f.exists())
        	{
        		System.out.println("file already exists , no need to create.");
        	}
        	else
        	{
        		f.createNewFile();
        		System.out.println("File successfully created");
        	}
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        }
	}

}
