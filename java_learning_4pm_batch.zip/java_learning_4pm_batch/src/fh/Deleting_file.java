package fh;

import java.io.File;

public class Deleting_file {

	public static void main(String[] args) 
	{
		try
		{
		File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\fh\\java_4_5batch_notes\\javanotes.txt");   
           if(f.delete())
           {
        	   System.out.println("File is successfully deleted");
           }
           else
           {
        	   if(f.exists())
        	   {
        	      System.out.println("File unable to delete, it still exists");
        	   }
           }
           } 
	    catch (Exception exception) {  
            exception.printStackTrace();  
        }  
	}
}
