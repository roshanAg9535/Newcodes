package fh;

import java.io.File;
import java.io.FileWriter;

public class Writing_into_a_file {

	public static void main(String[] args) 
	{
		try {
			File f = new File("D:\\java_4_to_5_batch\\java_learning_4pm_batch\\src\\fh\\java_4_5batch_notes\\javanotes.txt");
	        FileWriter fw = new FileWriter(f, true); 
	        fw.write("\nHello ecoders");
	        fw.close();
	        System.out.println("Contents were succesfully written in the file");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

}
