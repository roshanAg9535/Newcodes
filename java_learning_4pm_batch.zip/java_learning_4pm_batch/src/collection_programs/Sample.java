package collection_programs;

import java.util.*;

public class Sample {

	public static void main(String[] args) 
	{
		// Collection frame work
		
		ArrayList<String> l1 = new ArrayList<String>();
		
		l1.add("Hello");
		l1.add("Ecoders");
		l1.add("WElcome to java class");
		l1.add("Thank you very much for attending the class."); 

		System.out.println(l1);
			
	}
}
