package sorting;

public class Insertionsort {

	public static void main(String[] args) 
	{
		int a[] = {55,44,33,11,22};
		
		for (int i = 1; i<a.length; i++)
		{
		  int t = a[i]; int j;
			for(j= i-1; j>=0 && a[j] > t; j--)
			{
					a[j+1] = a[j];
					System.out.print(a[j]+" ");
					System.out.println();
			}
			a[j+1] = t;
			
		}
       
		// printing the sorted array
		System.out.println("The final sorted array is ");
		for(int i =0; i<a.length; i++)
		{
			System.out.print(a[i]+" ");
		}
	}

}
