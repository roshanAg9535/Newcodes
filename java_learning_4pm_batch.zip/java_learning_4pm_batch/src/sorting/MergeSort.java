package sorting;

public class MergeSort 
{
	int[] array;
	int[] tempArray;

	void arrangementForSort(int[] a) 
	{
		this.array = a;
		this.tempArray = new int[a.length];
		doSplitting(0, a.length - 1);
	}

	void doSplitting(int low, int high) {
	   if (low < high) {
	      int middle = low + (high - low) / 2;
	      doSplitting(low, middle);
	      doSplitting(middle + 1, high);
	      // now merge back the splitted arraysx
	      merging(low, middle, high);
	     }
	 }
	// 0  1  2  3   index values
	// 4, 1, 7, 3   actual values at that inde
	
	void merging(int low, int middle, int high) {
	    for (int i = low; i <= high; i++)
	    {
	      tempArray[i] = array[i];
	    }
	      int i = low;
	      int j = middle + 1;
	      int k = low;
	       while (i <= middle && j <= high) {
		if (tempArray[i] <= tempArray[j]) 
		{
		   array[k] = tempArray[i];
			i++;
		} 
		else 
		{
		    array[k] = tempArray[j];
			j++;
		  }
		k++;
		}
	
		while (i <= middle) 
		  {
			array[k] = tempArray[i];
			k++;
			i++;
		  }
		}

	public static void main(String[] args) 
	{
		int[] a = { 4, 1, 7, 3 };
		System.out.println("Before sorting");
		for (int i = 0; i < a.length; i++)
		System.out.print(a[i] + " ");
		System.out.println();
		
		
		new MergeSort().arrangementForSort(a);
		System.out.println("After sorting");
		for (int i = 0; i < a.length; i++)
		System.out.print(a[i] + " ");
		System.out.println();
	}
}
