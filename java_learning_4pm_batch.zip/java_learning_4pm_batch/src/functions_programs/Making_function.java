package functions_programs;

public class Making_function {
	
	
	public static void add()   // without arguments and no return type
	{
		int a = 10; 
		int b = 20;
		System.out.println(a+b);
	}
	
	public static void subract(int a, int b)  // with arguments and no return type
	{
		System.out.println(a-b);
	}
	
	public static int  multiply()        // withour arguments but with return type
	{
		int x = 5;
		int y = 2;
		return (x*y);
	}
	
	public static double divide(int m, int n)  // with return type and with arguments
	{
		return (m/n);        //   /,   %   
	}
	

	public static void main(String[] args)      // jvm - main()
	{
		add();
		subract(30, 10);
		int result = multiply();  // 5*2 = 10
		System.out.println(result);
		
		System.out.println(divide(7, 2));
	}

}
