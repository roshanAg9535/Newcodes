package composition;

class Demo
{
	int a= 10;
	int b = 20;
	static int c = 30;
}

public class Sample {
   public static void main(String [] args)
   {
	   Demo d = new Demo();   // composition
	   System.out.println(d.a);
	   System.out.println(d.b);
	   
	   System.out.println(Demo.c);
	   System.out.println(d.c);
   }
}
