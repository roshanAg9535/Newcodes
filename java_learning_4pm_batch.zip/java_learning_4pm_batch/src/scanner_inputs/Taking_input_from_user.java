package scanner_inputs;

import java.util.Scanner;

public class Taking_input_from_user {

	public static void main(String[] args) 
	{
		System.out.println("Enter an interger value");
		Scanner scint = new Scanner(System.in);
		int a = scint.nextInt();
		System.out.println("You have entered the integer value " + a);
		
		System.out.println("Enter an decimal, float value");
		Scanner scfloat = new Scanner(System.in);
		float f = scfloat.nextFloat();
		System.out.println("You have entered the decimal float value " + f);
		
		System.out.println("Enter an decimal value");
		Scanner scdouble = new Scanner(System.in);
		double d = scdouble.nextDouble();
		System.out.println("You have entered the decimal value " + d);
		
		System.out.println("Enter an single character value");
		Scanner scchar = new Scanner(System.in);
		char ch = scchar.next().charAt(0);
		System.out.println("You have entered character value " + ch);
		
		System.out.println("Enter an single word");
		Scanner scword = new Scanner(System.in);
		String word = scword.next();
		System.out.println("You have entered the word as " + word);
		
		System.out.println("Enter an sentence or a whole paragraph");
		Scanner scpara = new Scanner(System.in);
		String story = scpara.nextLine();
		System.out.println("Your story is \n\n" + story);
	}
}
