package excetion_handling_program;

public class Sample {

	public static void main(String[] args) 
	{
		System.out.println("hello ecoders");
		
		int a = 7;
		
		int b = 2;
		
		try
		{
		System.out.println(a/b);
		}
		catch(Exception ex)
		{
			System.out.println("this was the users fault , trying to divide by zero");
			ex.printStackTrace();
		}
		
		System.out.println("Program ends here");
		
	}

}
