package objectclassmthods;

public class Sample {
	int a = 10;

	public static void main()
	{
		Sample s1 = new Sample();
		
		System.out.println(s1);  //objectclassmthods.Sample@7d4991ad  , gives the full path of the object s1 
		
		System.out.println(s1.hashCode());  //2101973421, give the hashcode of the location of the object
		
		System.out.println(s1.toString()); // converts the location of the object into a string value 
		
		System.out.println(s1.equals(s1)); // used to compare two objects.. 
		
		Sample s2 = new Sample();
		System.out.println(s1.equals(s2));
		
		System.out.println(s1.getClass());  // class objectclassmthods.Sample
		
	}

}
