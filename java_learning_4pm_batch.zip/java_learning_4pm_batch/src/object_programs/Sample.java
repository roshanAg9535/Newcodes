package object_programs;

public class Sample {
	
	int a = 20;

	public static void main(String[] args) 
	{
		
		Sample s1 = new Sample();
		
		System.out.println(s1);
		
		System.out.println(s1.hashCode());
		
		System.out.println(s1.toString());
		
		System.out.println(s1.getClass());
		
		Sample s2 = new Sample();
		
		System.out.println(s1.equals(s2));
		
	}

}
