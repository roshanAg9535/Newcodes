package object_programs;

class PrintingName extends Thread
{
	public void run()
	{
		for(int i = 1; i<=100; i++)
		{
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("ecoders");
		}
	}
}

class PrintingNumbers implements Runnable
{
	public void run()
	{
		for(int i = 1; i<=100; i++)
		{
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}
}

public class Demo {
	public static void main(String[] args) throws InterruptedException {
//		PrintingName p1 = new PrintingName();
//		PrintingNumbers p2 = new PrintingNumbers();
//		
//		Thread t1 = new Thread(p1);
//		Thread t2 = new Thread(p2);
//		
//		t2.start();
//		
//		t1.start();
	    char c = 'e';
     
        System.out.println("The ASCII value of " + c + " is: " + (int)c);
        System.out.println((char)(c+5));
	}
}
