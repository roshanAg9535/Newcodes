package inheritance_programs;


//Single level inheritance :- when one child inherits properties from one single parent class 

class Parent    // super, base, parent
{
	int rs = 1000;  // non static :- multiple copies
}

class Suresh extends Parent   // child class, sub class
{
	// 
}

public class SingleLevel {    // jvm 

	public static void main(String[] args) {
		
		Suresh s = new Suresh();
		System.out.println(s.rs);
       
	}

}
