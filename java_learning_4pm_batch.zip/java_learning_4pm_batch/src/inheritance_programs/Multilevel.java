package inheritance_programs;

class Rajesh
{
	int rs = 1000;
}

class Raj extends Rajesh
{
	
}

class Raju  extends Raj
{
	
}


public class Multilevel {

	public static void main(String[] args) {
		Raju r = new Raju();
		System.out.println(r.rs);

	}

}
