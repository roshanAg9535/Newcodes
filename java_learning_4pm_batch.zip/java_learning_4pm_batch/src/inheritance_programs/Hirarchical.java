package inheritance_programs;

class Yash
{
	int rs = 10000;
}

class Ramesh extends Yash
{
	
}

class Sample extends Yash
{
	
}

class Smitha extends Sample
{
	
}

public class Hirarchical 
{
	public static void main(String [] args)
	{
		Sample s = new Sample();
	     System.out.println(s.rs);
	     
	     Smitha sm = new Smitha();
	     System.out.println(sm.rs);
	}

}
