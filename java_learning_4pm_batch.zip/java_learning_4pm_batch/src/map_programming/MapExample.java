package map_programming;

import java.util.*;

public class MapExample {

	public static void main(String[] args) {
		// key value pair
		// put() to insert and getKey() and getValue() for fetching the values
		
		HashMap map=new HashMap();  
	    // Map map=new HashMap();   both are acceptable
	    //Adding elements to map  
	    map.put(1,"Amit");  
	    map.put(5,"Rahul");  
	    map.put(2,"Jai");  
	    map.put(6,"Amit");  // intentionally added duplicate values
	    
        System.out.println(map); 
	}

}
