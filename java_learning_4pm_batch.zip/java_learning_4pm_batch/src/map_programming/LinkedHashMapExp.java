package map_programming;

import java.util.LinkedHashMap;

public class LinkedHashMapExp {

	public static void main(String[] args) {
		
		// maintains order of insertion :-
		
		LinkedHashMap map = new LinkedHashMap();
	    map.put(1,"Amit");  
	    map.put(5,"Rahul");  
	    map.put(2,"Jai");  
	    map.put(6,"Amit"); 
	    
	    System.out.println(map);
		

	}

}
